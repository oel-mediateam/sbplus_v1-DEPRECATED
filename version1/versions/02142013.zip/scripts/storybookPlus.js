$(document).ready(function () {
	
    var ua = navigator.userAgent, checker = { iphone: ua.match(/(iPhone|iPod|iPad)/), blackberry: ua.match(/BlackBerry/), android: ua.match(/Android/) };
    var mobile, url = window.location.href, m = url.split("=");
	
    if (m[1] == "false") { mobile = false; } else { mobile = true; }
	
    if ((checker.iphone || checker.ipod || checker.ipad || checker.blackberry || checker.android) && mobile) {
		
        $("#storybook_plus_wrapper").hide();
		
        $('body').html('<p>Your are viewing on a mobile device.<br /><a href="' + window.location.href + '?m=false' + '" target="_blank"><img src="https://mediastreamer.doit.wisc.edu/uwli-ltc/media/storybook_plus/img/view_on_full_site.png" width="250px" height="67px" alt="View on full site." border="0" /></a><br />New window/tap will open.</p>');
		
    } else {
		
        // global variable declarations
        var pFontSize = 14,
            firstList = true,
            topicCount = 0,
            counter = 1,
            previousIndex = 0,
            tocIndex = 0,
            audioPlaying = false,
            audioOut = false,
            XMLData, topicType, topicSrc, audioPlayer;
		
        // AJAX setup
        $.ajaxSetup({
            url: 'assets/topic.xml',
            type: 'GET',
            dataType: 'xml',
            accepts: 'xml',
            content: 'xml',
            contentType: 'xml; charset="utf-8"',
            cache: false
        });
		
        // Encoding XML data
        $.ajax({
            encoding: 'UTF-8',
            beforeSend: function (xhr) {
                xhr.overrideMimeType("xml; charset=utf-8");
                xhr.setRequestHeader("Accept", "text/xml")
            },
            success: function (xml) {
                setupXML(xml);
            },
            error: function (xhr, exception) {
                displayError(xhr.status, exception);
            }
        });
		
        // XML Setup function
        function setupXML(xml) {
			
            var SETUP = $(xml).find('setup');
            var TOPIC = $(xml).find('topic');
            var profile = $(xml).find('profile').text();
            var lessonTitle = (SETUP.find('lesson').text().length <= 0) ? 'Lesson name is not specified' : SETUP.find('lesson').text();
            var instructor = (SETUP.find('instructor').text().length <= 0) ? 'Instructor name is not specified' : '<a class="instructorP" href="#profile">' + SETUP.find('instructor').text() + '</a>';
			
            XMLData = $(xml);
			
            $('#lessonTitle').html(lessonTitle);
            $('#instructorName').html(instructor);
            $('#bio').html(profile);
			
            topicSrc = new Array();
			
            // loop through each topic node to get lesson topics
            // display each topic to web page as well
            TOPIC.each(function () {
				
                var topicTitle = $(this).attr('title');
				
                topicSrc[topicCount] = $(this).attr('src');
                topicCount++;
				
                if (firstList === true) {
					
                    $('#selectable').html('<li class="ui-widget-content" title="' + topicTitle + '">' + topicTitle + '</li>');
                    firstList = false;
					
                } else {
					
                    $('#selectable').append('<li class="ui-widget-content" title="' + topicTitle + '">' + topicTitle + '</li>');
					
                }
				
            });
			
			// initalize the player
            initializePlayer();
			
        }
		
        // initialized player function
        function initializePlayer() {
			
			$("#storybook_plus_wrapper").show();
			
            // hide error message div tag
            $('#errorMsg').fadeOut();
            loadSlide(topicSrc[0], counter);
			
            // enable table of content selection
            $('#selectable').selectable({
				
                stop: function () {
					
                    $(".ui-selected", this).each(function () {
						
                        tocIndex = $("#selectable li").index(this);
						
                    });
					
                    $('#slide').addClass('loading');
					
                    if (tocIndex != previousIndex) {
						
                        loadSlide(topicSrc[tocIndex], tocIndex + 1);
                        previousIndex = tocIndex;
						
                    }
                }
				
            });
			
            // select the first item
            $('#selectable li:first').addClass('ui-selected');
			
            // set the instructor picture
            $('#photo').html('<img src="assets/pic.jpg" width="200" height="300" alt="Instructor Photo" border="0" />');
			
            // enable fancy box for profile panel
            $("a#info, a.instructorP").fancybox({
                'hideOnContentClick': false,
                'autoDimensions': true,
                'overlayOpacity': .75,
                'overlayColor': '#000'
            });
			
            // display current font size
            $('#pFontSizeIndicator').html(pFontSize);
			
        }
		
        // binding left and right click event
        $('#leftBtn').bind('click', function () {
			
            counter--;
			
            if (counter <= 0) {
				
                counter = topicCount;
				
            }
			
            $('#slide').addClass('loading');
            loadSlide(topicSrc[counter - 1], counter);
			
        });
		
        $('#rightBtn').bind('click', function () {
			
            counter++;
			
            if (counter > topicCount) {
				
                counter = 1;
				
            }
			
            $('#slide').addClass('loading');
            loadSlide(topicSrc[counter - 1], counter);
			
        });
		
        // binding increasing and decreasing font size buttons
        $('#fontMinusBtn').bind('click', function () {
			
            var lineHeight;
			
            pFontSize -= 2;
            lineHeight = (pFontSize + 3) + 'px';
			
            if (pFontSize <= 14) {
				
                pFontSize = 14;
                lineHeight = (pFontSize + 3) + 'px';
				
            }
			
            $('#note p').css({
                'font-size': pFontSize,
                'line-height': lineHeight
            });
			
            $('#pFontSizeIndicator').html(pFontSize);
			
        });
		
        $('#fontPlusBtn').bind('click', function () {
			
            pFontSize += 2;
            lineHeight = (pFontSize + 3) + 'px';
			
            if (pFontSize >= 28) {
				
                pFontSize = 28;
                lineHeight = (pFontSize + 3) + 'px';
				
            }
			
            $('#note p').css({
                'font-size': pFontSize,
                'line-height': lineHeight
            });
			
            $('#pFontSizeIndicator').html(pFontSize);
			
        });
		
        // load selected slide
        function loadSlide(sn, sNum) {
			
            var currentNum, noteNum;
			
            sNum = (sNum < 10) ? '0' + sNum : sNum;
            currentNum = Number(sNum) - 1;
            noteNum = Number(sNum) - 1;
			
            if (sn.substring(0, sn.indexOf(":") + 1) == "image:") {
				
                var img = new Image(),
                    imgPath, imgCaption;
					
                imgPath = 'assets/slides/' + sn.substring(sn.indexOf(":") + 1) + '.png';
                imgCaption = $('#selectable li').get(currentNum).innerHTML;
				
                $(img).load(function () {
					
                    $(this).hide();
                    $('#slide').removeClass('loading');
                    $('#slide').html('<a id="img" title="' + imgCaption + '"href="' + imgPath + '">');
                    $('#slide #img').html(img);
                    $('#slide').append('</a>');
					
                    $(this).fadeIn();
					
                    $('a#img').fancybox({ closeBtn: true, autoSize: true });
					
                }).error(function (error) { 
				
					$('#slide').html('<p><strong>Error</strong>: image not found. Image path: ' + imgPath + '</p><p>Total number of slides: ' + topicCount + '</p>');
					
					}).attr({ 'src': imgPath, 'border': 0 });
				
            } else if (sn.substring(0, sn.indexOf(":") + 1) == "youtube:") {
				
                $('#slide').removeClass('loading');
				
                $('#slide').html('<iframe width="640" height="360" src="https://www.youtube.com/embed/' + sn.substring(sn.indexOf(":") + 1) + '?autoplay=1&rel=0" frameborder="0" allowfullscreen></iframe>');
				
            } else if (sn.substring(0, sn.indexOf(":") + 1) == "video:") {
				
                $('#slide').html('<video src="assets/video/' + sn.substring(sn.indexOf(":") + 1) + '.mp4" controls="controls" autoplay="autoplay" preload="none" width="640" height="360"><object width="640" height="360" type="application/x-shockwave-flash" data="assets/htmlPlayer/flashmediaelement.swf"><param name="movie" value="assets/htmlPlayer/flashmediaelement.swf" /><param name="flashvars" value="controls=true&file=assets/video/' + sn.substring(sn.indexOf(":") + 1) + '.mp4" /></object></video>');
				
                $('video').mediaelementplayer({
                    defaultVideoWidth: 640,
                    defaultVideoHeight: 360,
                    startVolume: 0.8,
                    loop: false,
                    enableAutosize: true,
                    features: ['playpause', 'progress', 'current', 'duration', 'volume', 'fullscreen'],
                    alwaysShowControls: false,
                    iPadUseNativeControls: false,
                    iPhoneUseNativeControls: false,
                    AndroidUseNativeControls: false,
                    pauseOtherPlayers: true
                });
				
            } else if (sn.substring(0, sn.indexOf(":") + 1) == "swf:") {
				
                $('#slide').removeClass('loading');
				
                $('#slide').html('<object width="640" height="360" type="application/x-shockwave-flash" data="assets/swf/' + sn.substring(sn.indexOf(":") + 1) + '.swf"><param name="movie" value="assets/swf/' + sn + '.swf" /><p>Your web browser does not support Adobe Flash.</p></object>');
				
            } else if (sn.substring(0, sn.indexOf(":") + 1) == "image-audio:") {
				
                var img = new Image(),
                    imgPath, imgCaption;
					
                imgPath = 'assets/slides/' + sn.substring(sn.indexOf(":") + 1) + '.png';
                imgCaption = $('#selectable li').get(currentNum).innerHTML;
				
                $(img).load(function () {
					
                    $(this).hide();
					
                    $('#slide').removeClass('loading');
                    $('#slide').html('<a id="img" title="' + imgCaption + '"href="' + imgPath + '">');
                    $('#slide #img').html(img);
                    $('#slide').append('</a>');
                    $('#slide').append('<audio id="ap" src="assets/audio/' + sn.substring(sn.indexOf(":") + 1) + '.mp3" type="audio/mpeg" autoplay="autoplay" preload="none" controls="controls"><object width="640" height="360" type="application/x-shockwave-flash" data="assets/htmlPlayer/flashmediaelement.swf"><param name="movie" value="assets/htmlPlayer/flashmediaelement.swf" /><param name="flashvars" value="controls=true&file=assets/audio/' + sn.substring(sn.indexOf(":") + 1) + '.mp3" /></object></audio');
					
                    $(this).fadeIn();
					
                    $('a#img').fancybox({
                        closeBtn: true,
                        autoSize: true
                    });
					
                    if (!audioPlaying) {
						
                        audioPlayer = new MediaElementPlayer('#ap', {
                            audioWidth: 640,
                            audioHeight: 30,
                            startVolume: 0.8,
                            loop: false,
                            enableAutosize: true,
                            iPadUseNativeControls: false,
                            iPhoneUseNativeControls: false,
                            AndroidUseNativeControls: false,
                            pauseOtherPlayers: true
                        });
						
                        audioPlaying = true;
						
                        if (!audioOut) {
                            $(".mejs-audio").delay(3000).animate({
                                bottom: "-30"
                            }, 500, function () {
                                audioOut = true;
                            });
                        }
						
                        $('#slide, .mejs-audio').bind('mouseenter', function () {
                            $(".mejs-audio").animate({
                                bottom: "0"
                            }, 500, function () {
                                audioOut = false;
                            });
                        });
						
                        $('#slide, .mejs-audio').bind('mouseleave', function () {
                            $(".mejs-audio").delay(3000).animate({
                                bottom: "-30"
                            }, 500, function () {
                                audioOut = true;
                            });
                        });
						
                    }
					
                }).error(function (error) {
					
                    $('#slide').html('<p><strong>Error</strong>: image not found. Image path: ' + imgPath + '</p>');
					
                }).attr({ 'src': imgPath, 'border': 0 });
				
            } else {
				
                $('#slide').html("<p>ERROR!</p>");
				
            }
			
            // if audio is playing
            if (audioPlaying) {
				
                audioPlayer.pause();
                audioPlaying = false;
				
                $('#slide, .mejs-audio').unbind('mouseover');
                $('#slide, .mejs-audio').unbind('mouseleave');
				
            }
			
            // load current slide note and update the slide number
            loadNote(noteNum);
            updateSlideNum(sNum);
			
        }

        function loadNote(num) {
			
            var note = XMLData.find('topic:eq(' + num + ')').text();
			
            $('#note').html(note);
			
        }

        function updateSlideNum(num) {
			
            counter = num;
			
            $('#selectable li').each(function () {
                $(this).removeClass('ui-selected');
            });
			
            $('#selectable li:nth-child(' + Number(num) + ')').addClass('ui-selected');
            $("#currentStatus").html('Slide ' + num + ' of ' + topicCount);
			
        }
		
        // error handling function
        function displayError(status, exception) {
			
            var statusMsg, exceptionMsg; // hold status and error message
			
            // assign status
            if (status === 0) {
                statusMsg = '<strong>Error 0</strong> - Not connect. Please verify network.';
            } else if (status === 404) {
                statusMsg = '<strong>Error 404</strong> - Requested page not found.';
            } else if (status === 406) {
                statusMsg = '<strong>Error 406</strong> - Not acceptable error.';
            } else if (status === 500) {
                statusMsg = '<strong>Error 500</strong> - Internal Server Error.';
            } else {
                statusMsg = 'Unknow error';
            }
			
            // assign error
            if (exception === 'parsererror') {
                exceptionMsg = 'Requested XML parse failed.';
            } else if (exception === 'timeout') {
                exceptionMsg = 'Time out error.';
            } else if (exception === 'abort') {
                exceptionMsg = 'Ajax request aborted.';
            } else if (exception === "error") {
                exceptionMsg = 'HTTP / URL Error (most likely a 404 or 406).';
            } else {
                exceptionMsg = ('Uncaught Error.\n' + status.responseText);
            }
			
            $('#preloader').fadeOut(); // hide preloader div tag
            $('#player').fadeOut(); // hide player div tag
            $('#errorMsg').html('<p>' + statusMsg + '<br />' + exceptionMsg + '</p>'); // display error message
			
        }
		
    }
	
});